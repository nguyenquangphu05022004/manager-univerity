create view vw_student_subject
  as
    select se.id,
           s.fullname,
           sj.subjectname as subjectname,
           sj.subject_id  as subjectcode,
           sj.start_date  as startdate,
           sj.end_date    as enddate,
           g.code         as groupcode,
           sj.credit,
           s.id           as studentid,
           sj.id          as subjectid,
           se.modifiedby as modifiedby,
           se.modifieddate as modifieddate
    from Students s
           inner join subject_exchange se on s.id = se.student_id
           inner join subjects sj on sj.id = se.subject_id
           inner join groups g on sj.group_id = g.id
go

