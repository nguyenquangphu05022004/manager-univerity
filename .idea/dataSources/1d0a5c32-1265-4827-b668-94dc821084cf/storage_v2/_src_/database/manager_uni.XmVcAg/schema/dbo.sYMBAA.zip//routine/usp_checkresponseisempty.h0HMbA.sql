CREATE proc usp_CheckResponseIsEmpty(
    @studentRequestId bigint,
    @studentResponseId bigint
  )

    as
    begin
      select
        s5.student_request
      from student_request srq inner join
               student_response_request s5
               on srq.id = s5.student_request
                               inner join student_response srp
               on srp.id = s5.student_response
      where s5.student_request = @studentRequestId and
            s5.student_response = @studentResponseId
      if(@@ROWCOUNT = 0)
        begin
          return 0;
        end
      return 1;
    end
go

