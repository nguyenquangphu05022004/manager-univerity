CREATE trigger TR_Register_AfterInsert
  on register after insert
  as
  begin
    insert into grades(createby, createdate, modifiedby,
                       modifieddate, register_id)
    select
      ins.createby,ins.createdate, ins.modifiedby,
           ins.modifieddate, ins.id
    from inserted ins;

  end
go

