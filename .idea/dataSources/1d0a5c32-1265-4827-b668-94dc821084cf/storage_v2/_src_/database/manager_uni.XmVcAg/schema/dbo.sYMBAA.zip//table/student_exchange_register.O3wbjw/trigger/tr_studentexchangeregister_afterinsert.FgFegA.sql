create trigger TR_StudentExchangeRegister_AfterInsert
  on student_exchange_register
  after insert
as
  begin
    update register set is_exchange = 'true' 
    where id = (select ins.register_id 
                from inserted ins)
  end
go

