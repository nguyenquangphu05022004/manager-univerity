create   view vw_InfoAfterExchange
       as
       select distinct r.id as registerId,
                sj.subject_code as subjectCode,
                s2.fullname     as studentRequest,
                sj2.subjectname as subjectRequest,
                g2.code         as groupRequest,
                s1.fullname     as studentResponse,
                sj.subjectname  as subjectResponse,
                g.code          as groupCode

from students s1
       inner join register r on s1.id = r.student_id
       inner join subjects sj on r.subject_id = sj.id
       inner join subject_group sg on sj.id = sg.subject_id
       inner join groups g on sg.group_id = g.id
       inner join student_response sr on g.id = sr.group_id and sr.student_id = s1.id and
                                         sr.subject_id = sj.id
       inner join student_response_request request on sr.id = request.student_response
       inner join student_request sr2 on sr2.id = request.student_request
       inner join students s2 on s2.id = sr2.student_id
       inner join register r2 on s2.id = r2.student_id
       inner join subjects sj2 on r2.subject_id = sj2.id
       inner join subject_group
    s3 on s3.subject_id = sj2.id
       inner join groups g2 on s3.group_id = g2.id
                                 and sr2.subject_id = sj2.id and sr2.group_id = g2.id
go

